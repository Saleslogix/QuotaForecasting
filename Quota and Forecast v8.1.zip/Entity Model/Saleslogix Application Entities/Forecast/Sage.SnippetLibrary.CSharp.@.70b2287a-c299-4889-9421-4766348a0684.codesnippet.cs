/*
 * This metadata is used by the Sage platform.  Do not remove.
<snippetHeader xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" id="70b2287a-c299-4889-9421-4766348a0684">
 <assembly>Sage.SnippetLibrary.CSharp</assembly>
 <name>PeriodClosedWonAmtStep</name>
 <references>
  <reference>
   <assemblyName>Sage.Entity.Interfaces.dll</assemblyName>
   <hintPath>%BASEBUILDPATH%\interfaces\bin\Sage.Entity.Interfaces.dll</hintPath>
  </reference>
  <reference>
   <assemblyName>Sage.Form.Interfaces.dll</assemblyName>
   <hintPath>%BASEBUILDPATH%\formInterfaces\bin\Sage.Form.Interfaces.dll</hintPath>
  </reference>
  <reference>
   <assemblyName>Sage.Platform.dll</assemblyName>
   <hintPath>%BASEBUILDPATH%\assemblies\Sage.Platform.dll</hintPath>
  </reference>
  <reference>
   <assemblyName>Sage.SalesLogix.API.dll</assemblyName>
  </reference>
 </references>
</snippetHeader>
*/


#region Usings
using System;
using Sage.Entity.Interfaces;
using Sage.Form.Interfaces;
using Sage.SalesLogix.API;
#endregion Usings

namespace Sage.BusinessRules.CodeSnippets
{
    public static partial class ForecastBusinessRules
    {
        public static void PeriodClosedWonAmtStep( IForecast forecast, out Double result)
        {
			result = 0;
			//DateTime beginDate = forecast.BeginDate.Value.Date;
			//DateTime endDate = EndOfDay(forecast.EndDate.Value);
			
			foreach (IForecastOpportunity fo in forecast.ForecastOpportunities)
			{
				if (fo.OpportunityStatus == _closedWon)
				{
					if (fo.MaxPotential.HasValue)
					{
						result += fo.MaxPotential.Value;
					}
				}
			}
        }
    }
}