/*
 * This metadata is used by the Sage platform.  Do not remove.
<snippetHeader xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" id="e974c797-2d2b-4f00-a8b2-1cd1bb4209f1">
 <assembly>Sage.SnippetLibrary.CSharp</assembly>
 <name>PeriodQuotaAmtStep</name>
 <references>
  <reference>
   <assemblyName>Sage.Entity.Interfaces.dll</assemblyName>
   <hintPath>%BASEBUILDPATH%\interfaces\bin\Sage.Entity.Interfaces.dll</hintPath>
  </reference>
  <reference>
   <assemblyName>Sage.Form.Interfaces.dll</assemblyName>
   <hintPath>%BASEBUILDPATH%\formInterfaces\bin\Sage.Form.Interfaces.dll</hintPath>
  </reference>
  <reference>
   <assemblyName>Sage.Platform.dll</assemblyName>
   <hintPath>%BASEBUILDPATH%\assemblies\Sage.Platform.dll</hintPath>
  </reference>
  <reference>
   <assemblyName>Sage.SalesLogix.API.dll</assemblyName>
  </reference>
 </references>
</snippetHeader>
*/


#region Usings
using System;
using Sage.Entity.Interfaces;
using Sage.Form.Interfaces;
using Sage.SalesLogix.API;
#endregion Usings

namespace Sage.BusinessRules.CodeSnippets
{
	using NHibernate;
	using Sage.Platform.Orm;
	using Sage.Platform.Orm.Interfaces;
	
    public static partial class ForecastBusinessRules
    {
        public static void PeriodQuotaAmtStep( IForecast forecast, out Double result)
        {
			result = 0;
			
			DateTime beginDate = forecast.BeginDate.Value.Date;
			DateTime endDate = forecast.EndDate.Value.Date.AddHours(23).AddMinutes(59).AddSeconds(59);
			
            using (ISession session = new SessionScopeWrapper(true))
			{
				var query = session.QueryOver<Sage.Entity.Interfaces.IQuota>()
					.Where(x => ((x.BeginDate >= beginDate && x.EndDate <= endDate))
					&& x.AssignedTo == forecast.AssignedTo)
					.List();
				
				foreach (Sage.Entity.Interfaces.IQuota quota in query)
				{
					if (quota.Amount.HasValue)
						result += Convert.ToDouble(quota.Amount);
				}
			}
        }
    }
}