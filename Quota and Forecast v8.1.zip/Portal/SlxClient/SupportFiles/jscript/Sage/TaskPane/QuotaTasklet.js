/*globals Sage, dojo, dojox, dijit, Simplate, window, Sys, define */
define([
    'dojo/i18n!./nls/QuotaTasklet',
    'Sage/TaskPane/_BaseTaskPaneTasklet',
    'Sage/TaskPane/TaskPaneContent',
    'Sage/Utility'
],
function (i18nStrings, _BaseTaskPaneTasklet, TaskPaneContent, Utility) {
    var quotaTasklet = dojo.declare('Sage.TaskPane.QuotaTasklet', [_BaseTaskPaneTasklet, TaskPaneContent], {
        CloneQuotaTitle: 'Clone',
        taskItems: [],
        constructor: function () {
            dojo.mixin(this, i18nStrings);
            this.taskItems = [
                { taskId: 'CloneQuota', type: "Link", displayName: this.CloneQuotaTitle, clientAction: 'quotaTaskletActions.clickLink(\'_tskCloneQuota\');',
                    securedAction: 'Entities/Quota/Add'
                }
            ];
        },
		
		clickLink: function (action) {
			if (Utility.getModeId() === "list") {
				this.prepareSelectedRecords(this.actionItem(this, action));
			}
			else {
				this.linkClick(action);
			}
		},

        actionItem: function (self, action) {
			return function () {
				self.linkClick(action);
            }
        },

        linkClick: function (action) {
            var link = dojo.byId([this.clientId, action].join(''));
            if (link) {
                link.click();
            }
        }
    });
    return quotaTasklet;
});