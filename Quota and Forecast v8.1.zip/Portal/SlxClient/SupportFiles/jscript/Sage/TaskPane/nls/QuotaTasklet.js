define([],function () {
    var nls = {
        root: {
    },
"en": true
    };
    return nls;
});
