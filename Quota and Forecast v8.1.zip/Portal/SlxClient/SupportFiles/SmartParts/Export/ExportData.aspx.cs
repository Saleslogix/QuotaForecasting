using System;
using System.Collections.Generic;
using System.Data;
using System.Web;
using System.IO;
using Sage.Platform.Application;
using Sage.Platform;
using Sage.Platform.Data;
using Sage.Platform.Security;
using Sage.Entity.Interfaces;

public partial class SmartParts_ExportData : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
		string path = String.Format("{0}\\Libraries\\Export\\", GetSlxClientBaseUrl());
		string file = null;
		string contentDisposition = null;
		string contentType = "application/csv";
        bool result = false;
		
		switch (Action)
		{
            case "ExportForecastOpps":
                file = String.Format("{0}{1}.csv", path, UserId);
                CreateForecastOppsFile(file);
                contentDisposition = String.Format("attachment;filename={0}-ForecastOpps.csv", CleanFileName(ForecastDescription));
                contentType = "application/txt";
                break;
            default:
				break;
		}

        result = SendFile(file, contentType, contentDisposition);
    }

    private bool CreateForecastOppsFile(string file)
    {
        bool result = false;
        if (File.Exists(file))
        {
            File.Delete(file);
        }

        using (var session = new Sage.Platform.Orm.SessionScopeWrapper(true))
        {
            IList<IForecastOpportunity> forecastopps = session.QueryOver<IForecastOpportunity>()
                .Where(x => x.Forecast.Id == ForecastId)
                    .List<IForecastOpportunity>();

            if (forecastopps != null)
            {
                using (var writer = new StreamWriter(file, false))
                {
                    writer.WriteLine("\"Opportunity\",\"Status\",\"Min Potential\",\"Max Potential\",\"Close Probability\",\"Close Date\"");
                    foreach (IForecastOpportunity fo in forecastopps)
                    {
                        writer.WriteLine(String.Format("\"{0}\",\"{1}\",\"{2}\",\"{3}\",\"{4}\",\"{5}\"", fo.Opportunity.Description, fo.OpportunityStatus, fo.MinPotential, fo.MaxPotential, fo.CloseProbability, fo.OpportunityCloseDate.ToString()));
                    }
                    writer.Close();
                    writer.Dispose();
                    result = true;
                }
            }
        }
        return result;
    }

    private string CleanFileName(string file)
    {
        string[] empty = new string[] { ",", ":", "$", "#" };
        string[] underscore = new string[] { " " };

        foreach (string s in empty)
        {
            file = file.Replace(s, String.Empty);
        }

        foreach (string s in underscore)
        {
            file = file.Replace(s, "_");
        }

        return file;
    }

    private bool SendFile(string file, string contentType, string contentDisposition)
    {
        bool result = false;
        int iBlockSize = 1024 * 8;

        if (File.Exists(file))
        {
            var bytes = File.ReadAllBytes(file);
            if (bytes != null)
            {
                Response.Clear();
                Response.Cache.SetCacheability(HttpCacheability.NoCache);
                Response.Cache.SetNoStore();
                Response.Cache.SetExpires(DateTime.MinValue);
                Response.ContentType = contentType;
                Response.AppendHeader("Content-Disposition", contentDisposition); 
                int iResponseLength = bytes.Length;
                Response.AppendHeader("Content-Length", iResponseLength.ToString());
                Response.BufferOutput = (iBlockSize > iResponseLength);

                if (Response.BufferOutput.Equals(true))
                {
                    /* If the default block size is greater than the response length... */
                    Response.BinaryWrite(bytes);
                    Response.Flush();
                    Response.End();
                }
                else
                {
                    /* If the response length is greater than the default block size... */
                    /* Define the starting offset used to read from arrResponse */
                    int iOffset = 0;
                    /* Determine the number of BinaryWrites that will be used */
                    var iTotalBinaryWrites =
                        (int)Math.Ceiling((iResponseLength + 0.0) / iBlockSize);
                    for (int i = 0;
                         i < iTotalBinaryWrites && Response.IsClientConnected;
                         i++)
                    {
                        /* If we have less than the default block size to send back to the client... */
                        if ((iResponseLength - iOffset) < iBlockSize)
                        {
                            iBlockSize = (iResponseLength - iOffset);
                        }
                        /* The following should never evaluate to true */
                        if (iBlockSize.Equals(0))
                        {
                            /* Healthy bit of paranoia in force */
                            break;
                        }
                        /* Create the buffer that will hold the current data to send to the client */
                        var arrBuffer = new byte[iBlockSize];
                        /* Copy the bytes that we want to send back to the client from the original arrResponse */
                        Array.Copy(bytes, iOffset, arrBuffer, 0, iBlockSize);
                        /* Send the data to the client */
                        Response.BinaryWrite(arrBuffer);
                        /* Flush the repsponse so that it will be sent immediately */
                        Response.Flush();
                        /* Calcualte the next offset */
                        iOffset += iBlockSize;
                    }
                    Response.End();
                }
                result = true;
            }
        }
        return result;
    }

	private string Action
	{
		get
		{
			object o = Request.QueryString["Action"];
			return (o == null ? string.Empty : o.ToString());
		}
	}

    private string AccountId
    {
        get
        {
            object o = Request.QueryString["AccountID"];
            return (o == null ? string.Empty : o.ToString());
        }
    }
	
	private string ContactId
    {
        get
        {
            object o = Request.QueryString["ContactID"];
            return (o == null ? string.Empty : o.ToString());
        }
    }

    private string UserId
    {
        get
        {
			var userService = ApplicationContext.Current.Services.Get<IUserService>();
			return userService.UserId.Trim();		
        }
    }
	
    private string ForecastId
    {
        get
        {
			object o = Request.QueryString["ForecastID"];
            return (o == null ? string.Empty : o.ToString());
        }
    }
	
	private string ForecastDescription
	{
		get
		{
            IForecast forecast = EntityFactory.GetById<IForecast>(ForecastId);
            if (!String.IsNullOrEmpty(forecast.Description))
            {
                return forecast.Description.Trim();
            }
            else
            {
                return forecast.Id.ToString();
            }
		}
	}

    private string GetSlxClientBaseUrl()
    {
        return Server.MapPath("~");
    }

    private string ConnectionString
    {
        get
        {
			var dataService = ApplicationContext.Current.Services.Get<IDataService>();
			return dataService.GetConnectionString();
        }
    }
}