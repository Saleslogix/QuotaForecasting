using System;
using System.Collections;
using System.Collections.Generic;
using System.Web.UI;
using Sage.Platform.WebPortal.SmartParts;
using Sage.Platform.Application.UI;
using Sage.Entity.Interfaces;


public partial class CloneQuota : Sage.Platform.WebPortal.SmartParts.SmartPartInfoProvider
{


    private string _mode = string.Empty;
    
    
    /// <summary>
    /// Gets the smart part info.
    /// </summary>
    /// <param name="smartPartInfoType">Type of the smart part info.</param>
    /// <returns></returns>
    public override ISmartPartInfo GetSmartPartInfo(Type smartPartInfoType)
    {
            ToolsSmartPartInfo tinfo = new ToolsSmartPartInfo();

            foreach (Control c in CloneQuota_RTools.Controls)
            {
                tinfo.RightTools.Add(c);
            }
            tinfo.Title = GetTitle();
           return tinfo;          
    }
    
    /// <summary>
    /// Raises the <see cref="E:PreRender"/> event.
    /// </summary>
    /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
    protected override void OnPreRender(EventArgs e)
    {

        LoadView();

    }

    protected override void OnLoad(EventArgs e)
    {
        base.OnLoad(e);        
    }

    protected override void OnInit(EventArgs e)
    {
        base.OnInit(e);       
    }
   

    /// <summary>
    /// Handles the Click event of the ok button control.
    /// </summary>
    /// <param name="sender">The source of the event.</param>
    /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
    protected void OK_Click(object sender, EventArgs e)
    {
        Type context = GetContext();
        Clone();

        DialogService.CloseEventHappened(this, null);
    }

    private void Clone()
    {
		int periods = 1;
        int nPassed = 0;
        int nFailed = 0;

        periods = Convert.ToInt32(cbxPeriods.SelectedValue);
		
        IList<string> selectedQuotas = GetTargets();
        if (selectedQuotas != null)
        {
            foreach (string selectedId in selectedQuotas)
            {
				string id = selectedId;
				
				for (int i = 1; i <= periods; i++)
				{
					IQuota selectedQuota = Sage.Platform.EntityFactory.GetById<IQuota>(id);
					if (selectedQuota != null)
					{
						id = selectedQuota.Clone();
					}
				}
				nPassed++;
            }
            //System.Diagnostics.EventLog.WriteEntry("Quota",String.Format("Clone Quota for: {0}\nPassed: {1}\nFailed: {2}",status, nPassed, nFailed));

            Response.Redirect(string.Format("~/{0}.aspx?mode={1}", "Quota", "list"), false);
        }
    }
        
    private IList<string> GetTargets()
    {

        IList<string> ids =  null;
        if (DialogService.DialogParameters.ContainsKey("selectedIds"))
        {

            ids = DialogService.DialogParameters["selectedIds"] as IList<string>;
        }
        return ids;
    }

    private Type GetContext()
    {
        Type context = null;
       
        if (DialogService.DialogParameters.ContainsKey("context"))
        {

            context = DialogService.DialogParameters["context"] as Type;
        }
               
        return context;
    }

    private  string GetTitle()
    {
        Type context = GetContext();
        int count = GetSelectCount();
        string desc = GetEntityName(context, count);
        return string.Format(GetLocalResourceObject("Title.Caption").ToString(), count, desc);
        
    }

    private string GetDescription()
    {
        int count = GetSelectCount();
        Type context = GetContext();
        string desc = GetEntityName(context, count);
        return string.Format(GetLocalResourceObject("Description").ToString(), count, desc);
      
    }

    private string GetEntityName(Type entityType, int selectCount )
    {
        string desc = string.Empty;
        try
        {
                if (selectCount > 1)
                {
                    desc = GetLocalResourceObject("Quotas").ToString();
                }
                else
                {
                    desc = GetLocalResourceObject("Quota").ToString();
                }
            return desc;
        }
        catch (Exception)
        { }
        return "";
    }

    private int GetSelectCount()
    {
        int count = 0;
        IList<string> ids = GetTargets();
        if (ids != null)
        {
            count = ids.Count;
          
        }
        return count;
    }


    protected void CANCEL_Click(object sender, EventArgs e)
    {
    }

    protected override void OnWireEventHandlers()
    {
        base.OnWireEventHandlers();
         btnCancel.Click += new EventHandler(DialogService.CloseEventHappened); 

    }

    private void LoadView()
    {
    }  
}
